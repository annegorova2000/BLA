import React, { Component, useState} from 'react'
import { Container, Modal, Button, Card, Row, Col, Nav, Table, Form } from 'react-bootstrap'
import { YMaps, Map } from 'react-yandex-maps';
import Maps from '../Components/Maps.png' 


const mapState = { center: [55.76, 37.64], zoom: 10 };


const styles = {
  progress: {
  
  },
  row: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-around"
  },
  quad: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-around"
  },
  orders: {
    width: 426,
    height: 600,
    backgroundColor: "#999"
  },
  map: {
    width: 572,
    height: 600,
    backgroundColor: "#aeaeae"
  },
  tableQuad: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-around",
    margin: "auto",
    width: 1442,
    height: 206,
  }
}



export default function MapBasics() {


  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [showModal2, setShow2] = useState(false);

  const handleClose2 = () => setShow2(false);
  const handleShow2 = () => setShow2(true);


    return (
      <div style={styles.progress}>
        <div style={styles.row}>
        <div style={styles.orders}>
        <Card.Title >ЗАКАЗЫ</Card.Title>
           <Row xs={1} className="g-4">
            {Array.from({ length: 1}).map((_, idx) => (
              <Col>
                <Card>
                  <Card.Body>
                    <Card.Title>ЗАКАЗ №101101 21.06.21</Card.Title>
                    <Card.Text>
                      1. Книга #737322
                    </Card.Text>
                    <Card.Text>
                      2. Книга #273927
                    </Card.Text>
                    <div class="d-grid gap-2 col-8 mx-auto">
                        <a href="#" onClick={handleShow2} className="btn btn-outline-success me-md-2">ОЦЕНКА УСПЕШНОСТИ ДОСТАВКИ</a>
                        <button href="#" onClick={handleShow} className="btn btn-outline-success me-md-2">ОТПРАВИТЬ НА ПРОВЕРКУ ОРВД</button> 
                    </div>
                  </Card.Body>
                </Card>
                <Card>
                  <Card.Body>
                    <Card.Title>ЗАКАЗ №102028 22.06.21</Card.Title>
                    <Card.Text>
                      1. Книга #783863
                    </Card.Text>
                    <Card.Text>
                      2. Книга #000876
                    </Card.Text>
                  </Card.Body>
                </Card>
                <Card>
                  <Card.Body>
                    <Card.Title>ЗАКАЗ №565634 23.06.21</Card.Title>
                    <Card.Text>
                      1. Книга #008976
                    </Card.Text>
                    <Card.Text>
                      2. Книга #273927
                    </Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            ))}
            </Row>
         </div>
         <div style={styles.map}>
         <Card.Title >КАРТА</Card.Title>
              <YMaps>
                <div id="map-basics">
                    <Map state={mapState} />
                </div>
              </YMaps>
           </div>
        </div>
        <div style={styles.tableQuad}>
        <Card.Title >СПИСОК КОПТЕРОВ:</Card.Title>
                <>  
                  <Table striped bordered hover size="sm">
                        <thead>
                            <tr>
                            <th>Серийный номер</th>
                            <th>Наименование дрона</th>
                            <th>Характеристики</th>
                            <th>Статус</th>
                            <th>Заряд аккумулятора</th>
                            <th>Кнопка отправки</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>102102</td>
                                <td>Дрон Аня</td>
                                <td>Супер пупер</td>
                                <td>Зарряжен</td>
                                <td>100%</td>
                                <Button variant="outline-success">ОТПРАВИТЬ</Button>
                            </tr>
                            <tr>
                                <td>202202</td>
                                <td>Дрон Лиза</td>
                                <td>Мега супер пупер</td>
                                <td>Выполняет заказ</td>
                                <td>85%</td>
                                <Button variant="outline-success">ОТПРАВИТЬ</Button>
                            </tr>
                            <tr>
                                <td>303303</td>
                                <td>Дрон Даша</td>
                                <td>Очень классный</td>
                                <td>Идет заряд...</td>
                                <td>4%</td>
                                <Button variant="outline-success">ОТПРАВИТЬ</Button>
                            </tr>
                        </tbody>
                    </Table>
                </>
           </div>



            <Modal show={show} onHide={handleClose} animation={false}>
            <Modal.Header closeButton>
                    <Modal.Title>ФОРМА ПРОВЕРКИ ОРВД</Modal.Title>
                    </Modal.Header>

                        <Form>
                        <Row className="mb-3">
                            <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Организация</Form.Label>
                            <Form.Control type="name" placeholder="Введите название организации" />
                            </Form.Group>
                        </Row>

                        
                        <Form.Group className="mb-3" controlId="formGridAddress1">
                            <Form.Label>Дата</Form.Label>
                            <Form.Control placeholder="21.05.2021" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formGridAddress2">
                            <Form.Label>Время вылета</Form.Label>
                            <Form.Control placeholder="12:21:00" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formGridAddress2">
                            <Form.Label>Длительность полета</Form.Label>
                            <Form.Control placeholder="15 минут" />
                        </Form.Group>

                        <Row className="mb-3">


                            <Form.Group as={Col} controlId="formGridState">
                            <Form.Label>Выберете город</Form.Label>
                            <Form.Select defaultValue="Choose...">
                                <option>Выберете постамат</option>
                                <option>Москва</option>
                                <option>Санкт-Петербург</option>
                                <option>Самара</option>
                            </Form.Select>
                            </Form.Group>

                            <Form.Group as={Col} controlId="formGridState">
                            <Form.Label>Выберете постамат</Form.Label>
                            <Form.Select defaultValue="Choose...">
                                <option>Выберете постамат</option>
                                <option>Постамат 1</option>
                                <option>Постамат 2</option>
                                <option>Постамат 3</option>
                            </Form.Select>
                            </Form.Group>

                            
                            <Form.Group as={Col} controlId="formGridState">
                            <Form.Label>Выберете склад</Form.Label>
                            <Form.Select defaultValue="Choose...">
                                <option>Выберете </option>
                                <option>Склад 1</option>
                                <option>Склад 2</option>
                                <option>Склад 3</option>
                            </Form.Select>
                            </Form.Group>

                        </Row>
                        <Form.Label>Маршрут полета:</Form.Label>
                        <img
                                src={Maps}
                                height="400"
                                width="490"
                                className="d-inline-block align-top"
                                alt="Maps"
                                />


                        </Form>


                    <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Отмена
                    </Button>
                    <Button variant="primary" onClick={handleClose}>
                        Отправить
                    </Button>
                    </Modal.Footer>
          </Modal>

          <Modal show={showModal2} onHide={handleClose2} animation={false}>
            <Modal.Header closeButton>
                    <Modal.Title>ОЦЕНКА УСПЕШНОСТИ ДОСТАВКИ</Modal.Title>
                    </Modal.Header>

                        <Form>
                        <Row className="mb-3">
                            <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Оценка возможности полета:</Form.Label>
                            <Form.Control type="name" placeholder="Полет возможен" />
                            </Form.Group>
                        </Row>

                        
                        <Form.Group className="mb-3" controlId="formGridAddress1">
                            <Form.Label>Оценка успешности полетв:</Form.Label>
                            <Form.Control placeholder="98%" />
                        </Form.Group>
                        
                        <Form.Label>Маршрут полета:</Form.Label>
                        <img
                                src={Maps}
                                height="400"
                                width="490"
                                className="d-inline-block align-top"
                                alt="Maps"
                                />


                        </Form>


                    <Modal.Footer>
                    <Button variant="primary" onClick={handleClose2}>
                        ОK
                    </Button>
                    </Modal.Footer>
          </Modal>

      </div>
    );
  }



function Example() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Launch demo modal
      </Button>

      <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}








// <div style={styles.progress}> 
//       <div style={styles.orders}></div>
        //  <div style={styles.orders}>
        //    <Row xs={1} className="g-4">
        //     {Array.from({ length: 1}).map((_, idx) => (
        //       <Col>
        //         <Card>
        //           <Card.Body>
        //             <Card.Title>ЗАКАЗ №101101 21.06.21</Card.Title>
        //             <Card.Text>
        //               1. Книга #737322
        //             </Card.Text>
        //             <Card.Text>
        //               2. Книга #273927
        //             </Card.Text>
        //           </Card.Body>
        //         </Card>
        //         <Card>
        //           <Card.Body>
        //             <Card.Title>ЗАКАЗ №102028 22.06.21</Card.Title>
        //             <Card.Text>
        //               1. Книга #783863
        //             </Card.Text>
        //             <Card.Text>
        //               2. Книга #000876
        //             </Card.Text>
        //           </Card.Body>
        //         </Card>
        //         <Card>
        //           <Card.Body>
        //             <Card.Title>ЗАКАЗ №565634 23.06.21</Card.Title>
        //             <Card.Text>
        //               1. Книга #008976
        //             </Card.Text>
        //             <Card.Text>
        //               2. Книга #273927
        //             </Card.Text>
        //           </Card.Body>
        //         </Card>
        //       </Col>
        //     ))}
        //     </Row>
        //  </div>
//         <div style={styles.quad}>
          //  <div style={styles.map}>
          //    <p>maps</p>
          //     <YMaps>
          //       <div id="map-basics">
          //         {showMap &&
          //           <Map state={mapState} />}
          //       </div>
          //     </YMaps>
          //  </div>
           
//          </div>
//        </div>