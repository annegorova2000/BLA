import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './Components/Header';
import { BrowserRouter as Router, Switch, Route, Link, Routes } from 'react-router-dom'

import Completed from './Completed'
import Info from './Info'
import NewOrders from './NewOrders'
import Progress from './Progress'
import Urvd from './Urvd'

function Admin() {


  return (
    <div>
        <Router>
            <Routes>
                <Header />
                <Route path="/neworder" component={NewOrders} />
                <Route path="/progress" component={Progress} />
                <Route path="/completed" component={Completed} />
                <Route path="/info" component={Info} />
                <Route path="/urvd" component={Urvd} />
            </Routes>
        </Router>
    </div>
  );
}

export default Admin;
