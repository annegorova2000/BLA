// // import './App.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Header from './../Components/Header';
// import { BrowserRouter as Router, Switch, Route, Link, Routes } from 'react-router-dom'

// import Completed from './Completed'
// import Info from './Info'
// import NewOrders from './NewOrders'
// import Progress from './Progress'
// import Urvd from './Urvd'

// function Client() {


//   return (
//         <Router>
//             <Routes>
//                 <Header />
//                 <Route path="/neworder" component={NewOrders} />
//             <Routes />
//         <Router />
//   );
// }

// export default Client;
