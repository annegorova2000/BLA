import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './Components/Header';
import HeaderClient from './Components/HeaderClient';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import {useState} from 'react'

import Shop from './Pages/Shop'
import Basket from './Pages/Basket'
import OrderStatus from './Pages/OrderStatus'
import Completed from './Pages/Completed'
import Info from './Pages/Info'
import NewOrders from './Pages/NewOrders'
import Progress from './Pages/Progress'
import Urvd from './Pages/Urvd'
import Auth from './Pages/Auth';
import { Button } from 'bootstrap';

function App() {

  const [site, onChangeSite] = useState(true)

  function setSite (setSite) {

      if (site) {
        return (
          <div>

                <Header />
                <button onClick={() => setSite(!site)}>СМЕНИТЬ ПРАВА ДОСТУПА</button>
                <p>ADMIN</p>
                <Routes>
                    <Route path="/" element={<NewOrders />} />
                    <Route path="/progress" element={<Progress />} />
                    <Route path="/completed" element={<Completed />} />
                    <Route path="/info" element={<Info />} />
                    <Route path="/urvd" element={<Urvd />} />
                </Routes>
          </div>
        )
      } else {
        return (
          <div>

                <HeaderClient/>
                <button onClick={() => setSite(!site)}>СМЕНИТЬ ПРАВА ДОСТУПА</button>
                <p>CLIENT</p>
                <Routes>
                    <Route path="/shop" element={<Shop/>} />
                    <Route path="/basket" element={<Basket/>} />
                    <Route path="/orderstatus" element={<OrderStatus/>} />
                </Routes>
          </div>
        )
      }
  }

  return (
    <>
      <Router>
        {setSite(onChangeSite)}
        </Router>
    </>
  );
}

export default App;
